<?php
define('base_url', 'http://localhost/proyecto-php/TUMMUSS/');//definimos una constante para la ruta
define("controller_default", "productoController");//definimos una constante para que reconosca un controlador
define("action_default", "index");

