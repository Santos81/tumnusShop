<?php

$clientID = '989570407161-2v6ktp3mkbfg977jnm24tgeq0o10hf23.apps.googleusercontent.com';
$clientSecret = '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';
$redirectUri = 'http://localhost/proyecto-php/TUMMUSS/';
?>